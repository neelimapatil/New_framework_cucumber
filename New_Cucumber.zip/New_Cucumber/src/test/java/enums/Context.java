package enums;

public enum Context {
COMPANY_NAME;
}
