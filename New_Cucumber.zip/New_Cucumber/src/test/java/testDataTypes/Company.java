package testDataTypes;

import java.util.HashMap;
import java.util.Map;

public class Company {

public String cOMPANYNAME;
public String cOMPANYTYPE;
public String cOMPANYSUBTYPE;
public String cOMPANYADDRESS;
public String cOMPANYPHONE;
public String cOMPANYEMAIL;
public String cOMPANYPAN;
public String cOMPANYTIN;
public String cOMPANYMOBILE;
public String cOMPANYWEBSITE;
public String cOUNTRY;
public String sTATE;
public String cITY;
public String tOTALEMPLOYEE;
public Map<String, Object> additionalProperties = new HashMap<String, Object>();



}