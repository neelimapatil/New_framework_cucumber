package testDataTypes;

public class Users {
	public String username;
	public String password;
	public String userrole;
	public String status;
	public String errormessage;
}
